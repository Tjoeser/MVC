<?php

// require 'header.php';
var_dump($contacts);
// require 'footer.php';

?>